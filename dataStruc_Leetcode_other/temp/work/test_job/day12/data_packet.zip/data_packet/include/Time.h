// SrcFile   : DataPacket.cpp
//
// Create on : 2016-5-11    
//
// Author    : Gaoriyao
//
// Modify By  :
//
// Modify Time:
#ifndef TIME_H_
#define TIME_H_

int ShowCurTime();

int TimeStart();

int TimeEnd();

void TimeCost();

#endif
